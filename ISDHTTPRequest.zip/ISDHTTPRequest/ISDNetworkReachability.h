//
//  ISDNetworkReachability.h
//  ZMNewTest
//
//  Created by ChingHan on 2017/5/15.
//  Copyright © 2017年 ChingHan. All rights reserved.
//

#import <Foundation/Foundation.h>

/// -------------------
/// @name 网络类型监测工具
/// -------------------
@interface ISDNetworkReachability : NSObject

/*!
 * 网络类型监测入口，返回当前网络类型
 */
+ (NSString *)networkReachability;

@end
