//
//  ISDHttpRequest.h
//  ZMNewTest
//
//  Created by ChingHan on 2017/1/17.
//  Copyright © 2017年 ChingHan. All rights reserved.
//

/// ----------------
/// @name 网络请求工具
/// ----------------
#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, ISDResponseStatus) {
    ISDResponseStautusDefault,              // 不明闲置状态
    ISDResponseStautusRequestIntercepted,   // 没有产生过API请求
    ISDResponseStautusSuccessWithRightData, // API请求成功且返回数据正确
    ISDResponseStautusSuccessWithWrongData, // API请求成功但返回数据不正确
    ISDResponseStautusFailed,               // 网络请求失败返回错误信息
    ISDResponseStautusParamsError,          // 参数错误
    ISDResponseStautusTimeout,              // 请求超时
    ISDResponseStautusNoNetWork             // 网络不通
};

/**
 *  请求成功/失败的回调
 */
typedef void(^requestSucceed)(ISDResponseStatus responseStatus, id responseObject);
typedef void(^requestFailed)(ISDResponseStatus responseStatus, id responseObject);

@interface ISDHttpRequest : NSObject<NSURLSessionDelegate>

+ (instancetype)requestManager;

/**
 GET 请求

 @param serverIdentifier 服务器主地址（没有测试服务器可传nil）
 @param subURLString 拼接地址（如果不需要测试服务器，直接传这个地址就是完整的请求）
 @param params 请求的参数
 @param successCallback 成功回调
 @param failureCallback 失败回调
 */
+ (void)GETFromServerIdentifier:(NSString *)serverIdentifier
                   subURLString:(NSString *)subURLString
                     withParams:(NSDictionary *)params
                        success:(requestSucceed)successCallback
                        failure:(requestFailed)failureCallback;

/**
 POST 请求
 
 @param serverIdentifier 服务器主地址（没有测试服务器可传nil）
 @param subURLString 拼接地址（如果不需要测试服务器，直接传这个地址就是完整的请求）
 @param params 请求的参数
 @param successCallback 成功回调
 @param failureCallback 失败回调
 */
+ (void)POSTFromServerIdentifier:(NSString *)serverIdentifier
                    subURLString:(NSString *)subURLString
                      withParams:(NSDictionary *)params
                         success:(requestSucceed)successCallback
                         failure:(requestFailed)failureCallback;

@end
