//
//  ISDHttpRequest.m
//  ZMNewTest
//
//  Created by ChingHan on 2017/1/17.
//  Copyright © 2017年 ChingHan. All rights reserved.
//

#import "ISDHttpRequest.h"
#import "NSString+ISDPublicParameter.h"
#import "ISDCertification.h"
#import "ISDCertificateVerify.h"

static NSString * const kServerIdentifier = @"http://www.baidu.com";

@implementation ISDHttpRequest

+ (instancetype)requestManager
{
    static ISDHttpRequest *request = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        request = [[self alloc] init];
    });
    
    return request;
}

+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    static ISDHttpRequest *request = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        request = [super allocWithZone:zone];
    });
    
    return request;
}

#pragma mark - GET
+ (void)GETFromServerIdentifier:(NSString *)serverIdentifier subURLString:(NSString *)subURLString withParams:(NSDictionary *)params success:(requestSucceed)successCallback failure:(requestFailed)failureCallback
{
    NSString *incomeParams = [NSString publickParameterOfCertification];
    NSString *systemParams = [NSString publickParameterOfSystem];
    NSString *publicParams = [NSString stringWithFormat:@"%@&%@", incomeParams, systemParams];
    
    NSString *urlString = nil;
    // 如果有测试服务器，在这里拼一下主接口
    if (serverIdentifier) {
        urlString = [NSString stringWithFormat:@"%@%@", serverIdentifier, subURLString];
    }
    else {
        urlString = [NSString stringWithFormat:@"%@%@", kServerIdentifier, subURLString];
    }
    
    // 最终的接口
    NSString *requestString = [NSString stringWithFormat:@"%@?%@", urlString, publicParams];
    NSString *ecodeUrlString = [requestString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *URL = [NSURL URLWithString:ecodeUrlString];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration] delegate:[ISDHttpRequest requestManager] delegateQueue:nil];
    NSURLSessionTask *task = [session dataTaskWithURL:URL completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (data) {
            NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            successCallback ? successCallback(ISDResponseStautusSuccessWithRightData, dataDic) : nil;
        }
        else if (error) {
            failureCallback ? failureCallback(ISDResponseStautusFailed, error) : nil;
        }
    }];
    
    [task resume];
}

#pragma mark - POST
+ (void)POSTFromServerIdentifier:(NSString *)serverIdentifier subURLString:(NSString *)subURLString withParams:(NSDictionary *)params success:(requestSucceed)successCallback failure:(requestFailed)failureCallback
{
    NSString *incomeParams = [NSString publickParameterOfCertification];
    NSString *systemParams = [NSString publickParameterOfSystem];
    NSString *publicParams = [NSString stringWithFormat:@"%@&%@", incomeParams, systemParams];
    
    NSString *requestString = nil;
    NSString *urlString = nil;
    NSString *body = nil;
    
    // 如果有测试服务器，在这里拼一下主接口
    if (serverIdentifier) {
        urlString = [NSString stringWithFormat:@"%@%@", serverIdentifier, subURLString];
    }
    else {
        urlString = [NSString stringWithFormat:@"%@%@", kServerIdentifier, subURLString];
    }
    
    // 公共参数 + 请求参数
    if (params) {
        body = [self typeConversionFromDictionary:params];
        requestString = [NSString stringWithFormat:@"%@&%@", publicParams, body];
    }
    else {
        requestString = [NSString stringWithFormat:@"%@", publicParams];
    }

    NSURL *URL = [NSURL URLWithString:urlString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:URL];
    request.HTTPMethod = @"POST";
    request.HTTPBody = [requestString dataUsingEncoding:NSUTF8StringEncoding];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration] delegate:[ISDHttpRequest requestManager] delegateQueue:nil];
    NSURLSessionTask *task = [session dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (data) {
            NSDictionary *dataDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            successCallback ? successCallback(ISDResponseStautusSuccessWithRightData, dataDic) : nil;
        }
        else {
            failureCallback ? failureCallback(ISDResponseStautusFailed, error) : nil;
        }
    }];
    
    [task resume];
}

#pragma mark - 字典转字符串
+ (NSString *)typeConversionFromDictionary:(NSDictionary *)dict
{
    NSMutableString *mutString = [NSMutableString string];
    
    NSArray *keysArray = [dict allKeys];
    NSArray *valuesArr = [dict allValues];
    
    for (NSInteger i = 0; i < keysArray.count; i++) {
        NSString *keyString = [NSString stringWithFormat:@"%@", keysArray[i]];
        NSString *valueString = [NSString stringWithFormat:@"%@", valuesArr[i]];
        NSString *tempString = [NSString stringWithFormat:@"%@=%@&", keyString, valueString];
        
        [mutString appendString:tempString];
    }
    
    NSString *paramString = [mutString substringWithRange:NSMakeRange(0, (mutString.length - 1))];
    
    return paramString;
}

#pragma mark - 证书校验
- (void)URLSession:(NSURLSession *)session didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *credential))completionHandler
{
    [ISDCertificateVerify verifyWithChallenge:challenge complementHandler:^(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *credential) {
        
        NSLog(@"Certificate check completed");
        
        if (completionHandler) {
            completionHandler(disposition, credential);
        }
    }];
}

@end
