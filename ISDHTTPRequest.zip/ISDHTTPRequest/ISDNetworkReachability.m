
//
//  ISDNetworkReachability.m
//  ZMNewTest
//
//  Created by ChingHan on 2017/5/15.
//  Copyright © 2017年 ChingHan. All rights reserved.
//

#import "ISDNetworkReachability.h"
#import "ISDReachability.h"
#import <CoreTelephony/CTTelephonyNetworkInfo.h>

static NSString *const kReachabilityHostName = @"authcenter.58.com";

@implementation ISDNetworkReachability

+ (NSString *)networkReachability
{
    NSString *networkType = @"unknown";

    ISDReachability *reachability = [ISDReachability reachabilityWithHostName:kReachabilityHostName];
    
    switch ([reachability currentReachabilityStatus]) {
        case NotReachable:
            networkType = @"no network";
            break;
        case ReachableViaWiFi:
            networkType = @"Wifi";
            break;
        case ReachableViaWWAN:
            networkType = [self p_networkTypeInWAN];
            break;
        default:
            break;
    }
    return networkType;
}

#pragma mark - Private Method
+ (NSString *)p_networkTypeInWAN
{
    NSString *WANNetworkType = @"unknown";
    
    NSArray *typeString2G = @[CTRadioAccessTechnologyEdge,
                              CTRadioAccessTechnologyGPRS,
                              CTRadioAccessTechnologyCDMA1x
                              ];
    
    NSArray *typeString3G = @[CTRadioAccessTechnologyHSDPA,
                              CTRadioAccessTechnologyWCDMA,
                              CTRadioAccessTechnologyHSUPA,
                              CTRadioAccessTechnologyCDMAEVDORev0,
                              CTRadioAccessTechnologyCDMAEVDORevA,
                              CTRadioAccessTechnologyCDMAEVDORevB,
                              CTRadioAccessTechnologyeHRPD
                              ];
    
    NSArray *typeString4G = @[CTRadioAccessTechnologyLTE];
    
    CTTelephonyNetworkInfo *networkInfo = [[CTTelephonyNetworkInfo alloc] init];
    NSString *accessString = networkInfo.currentRadioAccessTechnology;
    
    if ([typeString2G containsObject:accessString]) {
        WANNetworkType = @"2G";
    }
    else if ([typeString3G containsObject:accessString]) {
        WANNetworkType = @"3G";
    }
    else if ([typeString4G containsObject:accessString]) {
        WANNetworkType = @"4G";
    }
    else {
        WANNetworkType = @"unknown";
    }
    
    return WANNetworkType;
}

@end
