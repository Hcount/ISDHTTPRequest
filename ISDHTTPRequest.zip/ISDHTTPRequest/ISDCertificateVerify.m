//
//  ISDCertificateVerify.m
//  ZMNewTest
//
//  Created by ChingHan on 2017/5/12.
//  Copyright © 2017年 ChingHan. All rights reserved.
//

#import "ISDCertificateVerify.h"

// 验证证书有效性
static BOOL serverTrustIsValid(SecTrustRef trust) {
    
    BOOL allowConnection = NO;
    
    // 假设验证结果无效
    SecTrustResultType trustResult = kSecTrustResultInvalid;
    // 函数内部递归的从叶节点证书到根证书验证
    OSStatus status = SecTrustEvaluate(trust, &trustResult);
    
    if (status == noErr) {
        allowConnection = (trustResult == kSecTrustResultProceed || trustResult == kSecTrustResultUnspecified);
    }
    
    return allowConnection;
}

@implementation ISDCertificateVerify

#pragma mark - Public Method
+ (void)verifyWithChallenge:(NSURLAuthenticationChallenge *)challenge complementHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential *))completionHandler
{
    NSURLSessionAuthChallengeDisposition disposition = NSURLSessionAuthChallengePerformDefaultHandling;
    __block NSURLCredential *credential = nil;
    
    if ([challenge.protectionSpace.authenticationMethod isEqualToString:NSURLAuthenticationMethodServerTrust]) {
        
        // 调用自定义验证过程
        if ([self p_customValidation:challenge]) {
            
            credential = [NSURLCredential credentialForTrust:challenge.protectionSpace.serverTrust];
            
            // 有效继续访问
            if (credential) {
                disposition = NSURLSessionAuthChallengeUseCredential;
            }
            // 无效 取消访问
            else {
                disposition = NSURLSessionAuthChallengeCancelAuthenticationChallenge;
            }
        }
    }
    
    if (completionHandler) {
        completionHandler(disposition, credential);
    }
}

#pragma mark - Private Method
// 自定义验证策略
+ (BOOL)p_customValidation:(NSURLAuthenticationChallenge *)challenge
{
    // 获取信任链验证的抽象实体
    SecTrustRef trust = challenge.protectionSpace.serverTrust;
    
    NSMutableArray *certficates = [NSMutableArray array];
    
    // 获取本地证书
    NSString *pathString = [[NSBundle mainBundle] pathForResource:@"baidu.com" ofType:@"cer"];
    NSData *certData = [NSData dataWithContentsOfFile:pathString];
    
    if (!certData) {
        return YES;
    }
    
    SecCertificateRef cerRef = SecCertificateCreateWithData(NULL, (__bridge CFDataRef)certData);
    [certficates addObject:(__bridge_transfer id)cerRef];
    
    // 设置锚点证书
    SecTrustSetAnchorCertificates(trust, (__bridge CFArrayRef)certficates);
    
    // 允许CA证书作为锚点
    // SecTrustSetAnchorCertificatesOnly(trust, false);
    
    BOOL allowConnection = serverTrustIsValid(trust);
    
    return allowConnection;
}

@end
