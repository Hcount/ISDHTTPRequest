//
//  ISDCertificateVerify.h
//  ZMNewTest
//
//  Created by ChingHan on 2017/5/12.
//  Copyright © 2017年 ChingHan. All rights reserved.
//

#import "ISDHttpRequest.h"

@interface ISDCertificateVerify : ISDHttpRequest

/** 接收服务质询，做本地证书校验，并回传结果*/
+ (void)verifyWithChallenge:(NSURLAuthenticationChallenge *)challenge
          complementHandler:(void (^)(NSURLSessionAuthChallengeDisposition disposition, NSURLCredential *credential))completionHandler;

@end
